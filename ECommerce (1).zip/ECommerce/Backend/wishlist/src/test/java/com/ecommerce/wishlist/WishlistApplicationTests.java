package com.ecommerce.wishlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
