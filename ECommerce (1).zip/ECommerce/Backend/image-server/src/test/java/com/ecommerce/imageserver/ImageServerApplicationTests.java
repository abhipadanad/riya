package com.ecommerce.imageserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
